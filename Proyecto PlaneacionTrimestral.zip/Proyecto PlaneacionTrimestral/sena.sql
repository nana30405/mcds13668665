-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-07-2017 a las 04:17:52
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sena`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ambientes`
--

CREATE TABLE `ambientes` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ambientes`
--

INSERT INTO `ambientes` (`id`, `nombre`, `estado`, `descripcion`, `created_at`, `updated_at`) VALUES
(2, 'sistemas 1', 'Activo', 'Ubicado en el Centro de Servicios Sena', '2017-07-31 05:57:56', '2017-07-31 05:57:56'),
(3, 'Sistemas 2', 'Activo', 'Ubicado en Centro Industrial sena', '2017-07-31 07:00:34', '2017-07-31 07:00:34'),
(4, 'Sistemas 3', 'Inactivo', 'Ubicado en centro Industrial Sena', '2017-07-31 07:03:36', '2017-07-31 07:04:20'),
(5, 'Auditorio', 'Activo', 'Ubicado en Centro de servicios Sena de Manizales Caldas', '2017-07-31 07:13:33', '2017-07-31 07:14:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `areas_formacion`
--

CREATE TABLE `areas_formacion` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area_competencia` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `centro` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `centros`
--

CREATE TABLE `centros` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `centros`
--

INSERT INTO `centros` (`id`, `nombre`, `descripcion`, `created_at`, `updated_at`) VALUES
(1, 'Ullam exercitationem.', 'Exercitationem voluptas tenetur quod reiciendis vel ex quisquam. Mollitia iure est et aliquam placeat. Animi aut consectetur iure non.', '2017-07-28 10:27:37', '2017-07-28 10:27:37'),
(2, 'Soluta quisquam consequatur.', 'Occaecati placeat cupiditate qui accusantium rerum qui at. Aut earum ad magnam quia ut. Possimus optio ab fuga voluptatem. Dignissimos eum consequuntur neque consequuntur.', '2017-07-28 10:27:37', '2017-07-28 10:27:37'),
(3, 'Pariatur ex sequi.', 'Adipisci omnis molestiae laudantium veniam est. In molestiae et est repellendus qui eos quas. Commodi officia ut omnis est. Aperiam distinctio aut sapiente voluptatem velit impedit. Ipsam reprehenderit sit cumque maxime nulla.', '2017-07-28 10:27:37', '2017-07-28 10:27:37'),
(4, 'Possimus quo.', 'Eius consequatur impedit est sit ut. Neque optio laboriosam qui dolores et commodi deleniti. In possimus consectetur dolor labore voluptatem earum. Nesciunt velit quae optio consequatur praesentium quis nihil.', '2017-07-28 10:27:37', '2017-07-28 10:27:37'),
(5, 'Et pariatur quia.', 'Eaque dicta et odit odio. Odio est voluptates est voluptas modi optio esse. Occaecati quidem commodi molestias repellendus et eos deleniti.\nDucimus in dolore molestiae. Dolorem et itaque id optio.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(6, 'Fuga praesentium.', 'Repellendus cum sint repellendus alias iste earum sunt. Omnis voluptatem tempora est id nam asperiores occaecati placeat. Mollitia omnis nostrum consequuntur quia autem commodi. Sunt est molestias rerum eum voluptates assumenda.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(7, 'Rerum qui sed.', 'Quis fugit numquam aut nihil. Et illo et quia itaque nesciunt. Repudiandae deleniti sequi et veritatis.\nConsequuntur excepturi qui ut rerum. Quasi porro tempora ut iure tenetur sed.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(8, 'Nam et ipsam.', 'Qui accusantium ut placeat ex. Quae repudiandae iusto suscipit. Id ut est aliquid vitae alias.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(9, 'Commodi optio.', 'Quia impedit non aperiam quo expedita voluptatem modi ex. Esse ex officiis dignissimos dolorum autem. Dolorum ut sunt nisi.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(10, 'Quia sint veniam.', 'Necessitatibus omnis dolorem ut. Voluptatum culpa error architecto voluptatum officia. Saepe voluptatum voluptatem accusantium deserunt. Aspernatur enim rerum molestiae sed.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(11, 'Placeat reiciendis.', 'Atque repellat non praesentium dolorum veniam. Ipsa dolores dolorem laborum nisi unde soluta inventore. Non aut modi officiis quis id.\nLaboriosam dicta consequatur maiores exercitationem. Ex tenetur consequuntur expedita aut alias error.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(12, 'Culpa expedita.', 'Minus ut veritatis vero aperiam. Minima autem ut dolor. Qui veniam ad ut qui maxime.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(13, 'Numquam ut.', 'Voluptas cumque laborum a. Quia beatae sint debitis neque ut sit vero. Sed qui illo error ad. Blanditiis cumque ducimus molestiae consequatur aliquid qui non.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(14, 'Alias quam veritatis.', 'Praesentium adipisci dolores quis est beatae in accusamus. Voluptatem est rerum cumque asperiores recusandae voluptas. Ullam placeat et inventore sapiente aut perspiciatis doloremque est. Dicta dolore perferendis id vero consequatur neque.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(15, 'Unde possimus eos.', 'Sed et impedit quasi doloremque est. Incidunt id consequatur commodi ut. Provident aut vero est cum. Ratione vel sequi at quo. Ipsam ad rerum nisi.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(16, 'Occaecati consequatur qui.', 'Exercitationem dolorum provident officiis iusto itaque. Et mollitia et nostrum nostrum aliquid. Nobis nisi incidunt consequatur pariatur eligendi molestiae alias voluptas.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(17, 'Et aut quod.', 'Pariatur itaque magnam temporibus natus sint. Quia aut aut nisi doloremque unde. Impedit quas amet nam architecto id. Consequuntur veniam nisi officiis eum ut rem in ab.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(18, 'Ducimus quibusdam.', 'Tempore voluptatem at et vero itaque nesciunt. A ut sed modi delectus. Similique provident suscipit voluptate ducimus saepe dolor. Nemo voluptatem ipsa delectus quisquam eos quis.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(19, 'Enim et.', 'Non minus ullam ut. Amet aspernatur ut odio repudiandae laborum sit. Ea commodi id cupiditate sint facilis repellendus aliquam cum. Quia maxime sint modi labore natus soluta.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(20, 'Ratione alias laudantium.', 'Iusto unde et ullam omnis doloribus corrupti. Velit sed ut eligendi voluptate possimus. Nemo qui quisquam quos non. Non saepe temporibus quia assumenda voluptatem vel.', '2017-07-28 10:27:38', '2017-07-28 10:27:38'),
(21, 'Amet omnis quia.', 'Consequatur sit ut nihil dolorem placeat distinctio. Consequuntur pariatur numquam esse a. Incidunt natus autem omnis veniam. Illum aliquam fugiat modi repellendus saepe.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(22, 'Nihil cumque quia.', 'Repellat libero ab aut. Suscipit magni nihil facere fuga quos doloremque et. Consequatur possimus adipisci animi dolorem. Voluptatum quos similique illo voluptas placeat sit distinctio. Voluptatem sed aspernatur non architecto.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(23, 'Voluptas sunt accusantium.', 'Praesentium provident ea accusamus id qui id. Debitis quo nostrum qui ea dolor animi reiciendis. Ducimus in consequatur est id aut provident.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(24, 'Voluptatem autem.', 'Laborum atque distinctio molestiae atque. Quod ut beatae non ut omnis. Et quo dolores molestiae autem itaque. Facere commodi officia enim cum illum.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(25, 'Soluta voluptates.', 'Qui enim accusamus voluptate. Dolorem ipsa repellendus placeat voluptas vero. Et sunt inventore sint voluptatem quod assumenda ut.\nNeque officia harum accusantium eaque dolorum et laborum. Ut veritatis occaecati voluptatem in.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(26, 'Hic cum.', 'Assumenda ullam quisquam hic rerum accusantium adipisci. Nulla ipsam incidunt sit molestiae nam quas dolore a. Quae provident quas aut quam culpa id architecto. Laudantium omnis culpa sunt blanditiis ut accusamus nulla.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(27, 'Voluptatem veritatis.', 'Ad dolores fugit maiores repudiandae sed possimus. Et qui et earum eligendi quaerat. Incidunt quo qui repellendus eum architecto dolorum eos sunt.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(28, 'Reprehenderit voluptatem.', 'Et sint omnis voluptates mollitia assumenda. Et excepturi tenetur officia ad iste. Qui qui quos esse corporis. Rerum deserunt omnis accusamus ut exercitationem dicta in.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(29, 'Illum vel fuga.', 'Ex modi voluptatem perspiciatis exercitationem aut ratione. Totam et quibusdam voluptatem nemo est et eos. Ea nulla illo ab magnam nostrum saepe aperiam. Ullam quia molestias laudantium dolorem est. Eius cumque consequatur vero totam et in et.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(30, 'Perspiciatis autem ipsa.', 'Ipsam sed ea totam dignissimos et. Et voluptatem asperiores molestiae magnam quo est vel dolores. Qui explicabo cum animi consequatur eveniet rerum ipsa. Fuga aut accusantium omnis.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(31, 'Sed beatae.', 'Aut aut esse est. Non aut reprehenderit et nisi officia. Temporibus facilis voluptates et adipisci labore quod. Occaecati fugit perferendis consectetur non corporis.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(32, 'Odio odio suscipit.', 'Qui modi id impedit non placeat qui magni. Iure dolor voluptatem nam soluta et quia error. Ducimus id sint maiores qui atque est.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(33, 'Molestiae sit.', 'Veritatis asperiores amet tempora dicta aliquid veritatis voluptas. Voluptas quibusdam nesciunt qui delectus deserunt qui. Earum occaecati qui similique omnis non. Libero eum incidunt nulla modi quo non. Molestiae est sunt explicabo quibusdam aut.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(34, 'Tempore quo modi.', 'Fuga adipisci nostrum et vel id vitae autem assumenda. Quis eaque modi et ut commodi debitis. Sed voluptas error voluptas. Quia sunt error repellat tempore.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(35, 'Illum voluptatem.', 'Ducimus cupiditate facere beatae explicabo. Non numquam atque dolore corrupti ea. Error ab cupiditate laudantium perferendis aut accusamus quisquam. Provident quis consectetur nostrum reiciendis consequatur et eum.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(36, 'Et harum.', 'Natus magni amet cupiditate aliquid. Mollitia dolores harum quaerat rerum quam eos. Sunt ex veniam et temporibus. Quaerat vitae asperiores libero est.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(37, 'Totam voluptatem.', 'Ipsum eligendi velit dolorem consequuntur iusto sint ex numquam. Et aut iure quod voluptate iste ut incidunt. Molestias quod nihil omnis dolorum. Enim dolorem fugiat non doloribus.', '2017-07-28 10:27:39', '2017-07-28 10:27:39'),
(38, 'Sint qui.', 'Error ut sed qui fuga quidem sed. Cumque tenetur quibusdam pariatur debitis quis eius. Similique maiores sequi corrupti qui. Quis earum et est delectus.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(39, 'Vitae qui dolore.', 'Amet et aspernatur qui rerum expedita esse voluptatem. Enim sunt ut facere quis architecto enim velit itaque. Dignissimos eos qui magni laudantium. Ipsa ea cum praesentium commodi.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(40, 'Ex sit tempora.', 'Tempore harum ut debitis tempore. Dolor maiores ut laboriosam libero. Suscipit expedita natus cumque veritatis voluptates voluptates officiis. Enim beatae consequatur rem voluptatum.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(41, 'Ut ex labore.', 'Est cumque totam culpa quod inventore eius. Praesentium maiores doloremque ipsam quo esse. Et doloremque provident quisquam cum excepturi ut aperiam.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(42, 'Praesentium dolor.', 'Consequuntur voluptatibus voluptatem accusantium consequuntur. Fuga dolorem aliquam quisquam qui eaque dolor. Quia et eum natus a quasi quibusdam ex. Nesciunt sit blanditiis expedita atque vitae.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(43, 'Eaque id doloremque.', 'Amet commodi voluptatem quo quia eos consequuntur odit. Facere voluptas repudiandae delectus ut. Dicta tempore eum iste ipsam.\nReprehenderit magni tempora odit. Doloribus ullam iste qui. Similique aliquid qui aperiam sit.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(44, 'Ipsum tenetur facilis.', 'Quia voluptate sint quia minus. Vel commodi cupiditate expedita officia nobis. Rem qui delectus et error qui id quaerat.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(45, 'Voluptatibus dignissimos.', 'Ut error voluptas numquam inventore. Sequi maiores porro a quia cum.\nRepellat minima in dolore tempora est ut accusantium. Vel libero qui autem omnis. Dignissimos architecto quam eligendi voluptatem deleniti pariatur.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(46, 'Iusto voluptas.', 'Unde et repellat sapiente sunt rem error. Non rerum nam assumenda. Sequi earum dolor fugit quis beatae.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(47, 'Sapiente adipisci.', 'Sunt fuga reiciendis delectus quos harum accusantium odio. Sapiente qui cumque sapiente excepturi. Dolores sit perspiciatis molestiae quas est autem ipsam. Quos aut temporibus odit quasi beatae tenetur enim.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(48, 'Quod eligendi.', 'Quo porro consequatur commodi in qui. Quidem accusamus rerum et nobis sed distinctio vel. Itaque ab vero qui.\nQuo officia natus omnis itaque quisquam. Et amet accusamus blanditiis porro numquam ab nostrum. Aperiam aut deserunt voluptatum aliquam.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(49, 'Rerum fugiat assumenda.', 'Explicabo explicabo iusto et neque rerum. Fuga ut ut et asperiores est vitae. Et veritatis sed delectus perspiciatis non molestiae.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(50, 'Ut expedita non.', 'Maxime distinctio soluta officia et. Et neque rem ratione sint dolores.\nExplicabo quis deserunt sit officiis saepe sint aut. Et facilis in perspiciatis quos quibusdam soluta quo aliquid. Illum assumenda non sunt architecto.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(51, 'Ipsa quia.', 'Reprehenderit ut tempora ex eligendi perspiciatis impedit sequi. Provident suscipit error et voluptatem. Aut molestias quidem ut ea maxime.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(52, 'Sed sint.', 'Est sed voluptatibus fuga similique dicta. Quaerat explicabo est et quas id occaecati nostrum. Porro pariatur ducimus impedit odit. Expedita repellat esse tenetur nulla laboriosam et est.', '2017-07-28 10:27:40', '2017-07-28 10:27:40'),
(53, 'Voluptas quae.', 'Nihil quos perferendis aut dolores velit suscipit. Adipisci ab modi sunt reiciendis quod.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(54, 'Expedita accusantium in.', 'Itaque et dolore autem reiciendis. Velit ut et iusto temporibus est blanditiis aut. Sunt ratione molestiae omnis neque.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(55, 'Dolorem at at.', 'Recusandae fuga necessitatibus cumque fugiat. Sit assumenda aliquid cupiditate iusto.\nAnimi voluptatem ut amet quae reprehenderit iusto. Nihil et quia vero minima ut. Sapiente accusamus tempore repudiandae aspernatur.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(56, 'Consequatur nihil.', 'Beatae eos molestiae maxime error est. Ut eveniet vero labore consequatur modi. Hic alias aut assumenda non. Culpa aut provident inventore esse suscipit magni architecto.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(57, 'Pariatur dolorem eius.', 'Cum quasi est laboriosam velit. Cumque voluptatibus enim consequatur velit necessitatibus ducimus repellat. Ab veniam facere et.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(58, 'Quia omnis.', 'Non id nihil labore qui sint. Illo numquam tempore et aut repellat qui sapiente. Aspernatur possimus blanditiis iusto eos ut. Dolore sed expedita sint.\nIpsam tenetur atque quia soluta aut. Tenetur dolorem officia cumque accusamus qui modi.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(59, 'Ut cupiditate.', 'Quaerat aut quis numquam. Id eum iure et sit minima cupiditate recusandae atque. Quae quae est suscipit dolor. Deleniti aut voluptas eius et repellendus. Ratione deserunt laboriosam voluptatibus cupiditate.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(60, 'Eum iste quos.', 'Consequuntur eum dicta non optio laudantium ipsa nesciunt molestiae. Et sed eum eos quia quibusdam fugit. Nam voluptatem perspiciatis et libero eius aliquid.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(61, 'Eaque veritatis.', 'Officia blanditiis maiores est quisquam exercitationem occaecati minus. Modi aliquam et quas deleniti saepe itaque incidunt. Ullam ut assumenda id nihil rerum et quia. Unde sequi sed iste et dicta.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(62, 'At dolorem.', 'Error rerum deserunt autem recusandae soluta sint eum. Possimus sint sunt vel ut eum. Eum molestiae alias rerum amet.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(63, 'Maxime nisi animi.', 'Dolorem non aliquam consequuntur pariatur voluptatum. Labore quisquam commodi rerum rerum voluptas aut. Aspernatur facilis repellat ducimus ea. Sit laudantium magni reprehenderit quo beatae.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(64, 'Et commodi.', 'Delectus adipisci nihil in ipsam inventore. Ut et libero asperiores qui id. At ducimus maiores quia eos omnis.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(65, 'Doloremque quis cum.', 'Nisi neque enim blanditiis officiis sed atque impedit. Velit mollitia dignissimos nobis nihil. Et dolores qui rerum rerum ratione. Et iste quod voluptates.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(66, 'Et iste.', 'Quasi facilis odio tenetur placeat vitae qui reprehenderit. Necessitatibus itaque facilis dolor sit consectetur. Id cum accusantium natus esse. Ut quia ad voluptatibus eum. Aut nihil error quos.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(67, 'Neque illo.', 'Minima facilis quidem dolores provident consequatur voluptatem doloremque. Hic totam commodi ut aut eligendi. Voluptas aut doloremque fugit sit fugiat eos. Optio possimus iure molestias ullam.', '2017-07-28 10:27:41', '2017-07-28 10:27:41'),
(68, 'Eveniet est.', 'Illo ipsum ducimus aut nisi ab repudiandae. Repellendus sint voluptatibus illo doloremque. Eaque ut beatae similique explicabo. Veniam vitae consequuntur sit ratione.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(69, 'Excepturi assumenda.', 'Animi voluptas consectetur quisquam quaerat odit dicta nostrum. Doloribus atque animi ut. Voluptatum quia optio veniam rerum dolor. Sint ea est fuga quia. Incidunt et labore id est.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(70, 'Sequi amet ut.', 'Ipsum dolores quibusdam illum inventore aut dignissimos ut. Et non voluptatum non totam ut architecto officia. Dolore officiis mollitia quia veniam fugiat.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(71, 'Omnis dolores mollitia.', 'Molestias neque fugit ea dolorem. Rerum autem temporibus sit sapiente. Et ea ducimus ut laudantium laboriosam numquam.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(72, 'Suscipit modi sapiente.', 'Porro similique excepturi blanditiis natus sint rem quia. Iste nisi hic consequatur veniam ratione animi. Laborum nobis necessitatibus est quo placeat incidunt. Totam modi possimus sunt voluptatum modi perspiciatis. Iste tenetur esse unde.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(73, 'Quia quia.', 'Non repellat quia quae. Optio ducimus aliquam exercitationem minima aspernatur labore eum. Enim architecto tempora sit.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(74, 'Velit eos.', 'Autem ut necessitatibus nemo eligendi nisi minima eos. Vel voluptate quibusdam voluptas et quisquam. Quo dignissimos possimus adipisci.\nRepudiandae consectetur saepe aut qui. Iste sunt est ea quam libero.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(75, 'Quia error.', 'Voluptas ut dolor sed odit sunt perferendis. Id ullam et quia minima ratione. Sapiente non molestiae blanditiis iure eum dolores aut. Sit ab nulla odit alias.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(76, 'Veritatis deleniti.', 'Et perferendis est soluta est. Voluptatum minima sed provident ut. Sint quaerat ab nihil asperiores in non omnis. Ex quo aperiam dolores et. Harum quis perspiciatis consequatur quas officiis.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(77, 'Recusandae rerum.', 'Aut veniam ut consectetur consequatur earum commodi numquam. Non qui odit totam aut. Ea labore facilis molestias voluptas ut mollitia.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(78, 'Illum sunt.', 'Placeat neque nihil porro sequi maxime aut repellendus. Atque deserunt voluptas quisquam odit deserunt adipisci tenetur. Dolore voluptate voluptatum sit dicta sint sed. Modi rerum et excepturi.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(79, 'Eum consequatur asperiores.', 'Tenetur nisi similique quisquam repudiandae cupiditate. Et illo quo dolor explicabo architecto. Molestiae perferendis illum et soluta laborum veritatis.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(80, 'Blanditiis atque.', 'Harum nihil nihil et tempora ea. Et vel vero qui et qui. Reiciendis sunt sunt consequuntur perferendis nam quo nihil.', '2017-07-28 10:27:42', '2017-07-28 10:27:42'),
(81, 'Institución  Educativa Anserma', 'ubicada en Caldas', '2017-07-28 10:38:54', '2017-07-28 10:38:54'),
(82, 'Centro de Servcios Cervantes', 'Ubicada en Manizales Caldas', '2017-07-30 07:41:07', '2017-07-30 07:41:43'),
(83, 'Centro  de Formación Barrios Unidos', 'Ubicado en Manizales Caldas', '2017-07-30 08:54:23', '2017-07-30 08:54:23'),
(84, 'Centro de Formación Chinchina', 'situada en las afueras de Manizales', '2017-07-30 09:27:34', '2017-07-30 09:27:34'),
(85, 'Centro de Formación Manzanares', 'Ubicado en Caldas', '2017-07-30 09:52:20', '2017-07-30 09:52:20'),
(86, 'Centro de Formación Villamaria', 'Ubicada en Caldas', '2017-07-31 03:08:52', '2017-07-31 03:08:52'),
(87, 'Centro de Formacion Palestina', 'Ubicado en Caldas', '2017-07-31 04:46:45', '2017-07-31 04:46:45'),
(88, 'Centro de Formación los Andes', 'Ubicado en Chinchina en Caldas', '2017-07-31 06:57:56', '2017-07-31 06:57:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(41, '2014_10_12_000000_create_users_table', 1),
(42, '2014_10_12_100000_create_password_resets_table', 1),
(43, '2017_07_11_214438_create_centros_table', 1),
(44, '2017_07_28_050708_create_ambientes_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'julian', 'julianherrera66@hotmail.com', '$2y$10$0CATg9daJU4n8HGSShwdOutYP5H4pj5PhU9TUdVJXS6dtYfQdXvQW', NULL, NULL, NULL),
(2, 'maria', 'maria@hotmail.com', '$2y$10$kAyb0Eta1LuPywN7K3qHyey8Mi1XYeT7XjdD9UEVSSnngJNRZevmi', NULL, NULL, NULL),
(3, 'flor', 'flor@hotmail.es', '$2y$10$ealDH5r9cAxPyt45XxbyIuqgdYlu2cBUo2kZlFQE8/5pjBfvjj9YO', NULL, '2017-07-28 11:19:20', '2017-07-28 11:19:20');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ambientes`
--
ALTER TABLE `ambientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `areas_formacion`
--
ALTER TABLE `areas_formacion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `centros`
--
ALTER TABLE `centros`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ambientes`
--
ALTER TABLE `ambientes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `areas_formacion`
--
ALTER TABLE `areas_formacion`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `centros`
--
ALTER TABLE `centros`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
