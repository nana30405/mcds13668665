@extends('layouts.app')
    @section('content')
<div class="container">
    <div class="row">
     <table>
        <tr>
            <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Centros de Formacion</i> </a>
            </td>       
    
            <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Instructores</i> </a>
            </td>    
              <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Fichas</i> </a>
            </td>  
            <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Grupos de Formacion</i> </a>
            </td> 
            <td> <a class="btn btn-default btn-block" href="{{route('ambientes.index')}}">
                <i class="fa fa-hand-o-right">Ambientes</i> </a>
            </td> 
            <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Areas de Competencia</i> </a>
            </td>  
            <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Especialidad</i> </a>
            </td> 
            <td> <a class="btn btn-default btn-block" href="{{route('centros.index')}}">
                <i class="fa fa-hand-o-right">Instituciones Asociadas</i> </a>
            </td>     
        </tr>
     </table>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a class="btn btn-success btn-block" href="{{route('centros.index')}}">
                        <i class="fa fa-hand-o-right">
                            Centros Formacion
                        </i>
                    </a>
                </div>
                <div class="panel-body">
                    Estado
                </div>
                <div class="panel-body">
                    Area de Competencia
                </div>
                <div class="panel-body">
                    Area de Formacion
                </div>
                <div class="panel-body">
                    Instructor
                </div>
                <div class="panel-body">
                    Tipo Documento
                </div>
                <div class="panel-body">
                    Tipo Contrato
                </div>
                <div class="panel-body">
                    Grupos Formacion
                </div>
                <div class="panel-body">
                    Fichas
                </div>
                <div class="panel-body">
                    Modalidad
                </div>
                <div class="panel-body">
                    Tipo Formacion
                </div>
                <div class="panel-body">
                    instructores de Apoyo
                </div>
                <div class="panel-body">
                    Apoyo
                </div>
                <div class="panel-body">
                    Fichas
                </div>
                <div class="panel-body">
                    Instituciones Asociadas
                </div>
                <div class="panel-body">
                    Tipo Institucion
                </div>
                <div class="panel-body">
                    Municipios
                </div>
                <div class="panel-body">
                    Region
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
