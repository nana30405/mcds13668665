<?php $__env->startSection('content'); ?>
<div class="col-xs-10">
    <hr>
        <a class="btn btn-success" href="<?php echo e(url('centros/create')); ?>">
            <i class="fa fa-plus">
            </i>
            Adicionar Centro
        </a>
        <?php echo $__env->make('centros.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th width="20px">
                        Id
                    </th>
                    <th>
                        Nombre
                    </th>
                    <th>
                        Descripcion
                    </th>
                    <th colspan="3">
                        Acciones
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($centro->id); ?>

                    </td>
                    <td>
                        <?php echo e($centro->nombre); ?>

                    </td>
                    <td>
                        <strong>
                            <?php echo e($centro->descripcion); ?>

                        </strong>
                        <?php echo e($centro->short); ?>

                    </td>
                    <td>
                        <a class="btn btn-info btn-lg " href="<?php echo e(route('centros.show',$centro->id)); ?>">
                            <i class="fa fa-search">
                            </i>
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-info btn-lg " href="<?php echo e(route('centros.edit',$centro->id)); ?>">
                            <i class="fa fa-pencil-square-o">
                            </i>
                        </a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('centros.destroy',$centro->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input name="_method" type="hidden" value="DELETE">
                                <button class="btn btn-danger btn-lg ">
                                    <i class="fa fa-trash-o">
                                    </i>
                                </button>
                            </input>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $centros->render(); ?>

    </hr>
</div>
<div class="col-sm-2">
    <?php echo $__env->make('centros.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>