    <?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a class="btn btn-success btn-block" href="<?php echo e(route('centros.index')); ?>">
                        <i class="fa fa-hand-o-right">
                            Centros Formacion
                        </i>
                    </a>
                </div>
                <div class="panel-body">
                    Estado
                </div>
                <div class="panel-body">
                    Area de Competencia
                </div>
                <div class="panel-body">
                    Area de Formacion
                </div>
                <div class="panel-body">
                    Instructor
                </div>
                <div class="panel-body">
                    Tipo Documento
                </div>
                <div class="panel-body">
                    Tipo Contrato
                </div>
                <div class="panel-body">
                    Grupos Formacion
                </div>
                <div class="panel-body">
                    Fichas
                </div>
                <div class="panel-body">
                    Modalidad
                </div>
                <div class="panel-body">
                    Tipo Formacion
                </div>
                <div class="panel-body">
                    instructores de Apoyo
                </div>
                <div class="panel-body">
                    Apoyo
                </div>
                <div class="panel-body">
                    Fichas
                </div>
                <div class="panel-body">
                    Instituciones Asociadas
                </div>
                <div class="panel-body">
                    Tipo Institucion
                </div>
                <div class="panel-body">
                    Municipios
                </div>
                <div class="panel-body">
                    Region
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>