<?php $__env->startSection('content'); ?>
<div class="col-sm-8">
    <h2>
        Editar ambiente
        <a class="btn btn btn-info pull-right" href="<?php echo e(route('ambientes.index')); ?>">
            <i aria-hidden="true" class="fa fa-undo">
                Regresar
            </i>
        </a>
    </h2>
    <?php echo $__env->make('ambientes.fragment.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<?php echo Form::model($ambiente, ['route' => ['ambientes.update', $ambiente->id], 'method' => 'PUT']); ?>

			
			<?php echo $__env->make('ambientes.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
		<?php echo Form::close(); ?>

</div>
<div class="col-xs-12 col-sm-4">
    <?php echo $__env->make('ambientes.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>