<?php $__env->startSection('content'); ?>
<div class="col-sm-8">
    <h1 class="lead">
        <i class="fa fa-plus">
        </i>
        Adicionar Centro
        <a class="btn btn btn-info pull-right" href="<?php echo e(route('centros.index')); ?>">
            <i aria-hidden="true" class="fa fa-undo">
                Regresar
            </i>
        </a>
    </h1>
    <hr>
        <?php echo $__env->make('centros.fragment.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<?php echo Form::open(['route' => 'centros.store']); ?>

			
			<?php echo $__env->make('centros.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
		<?php echo Form::close(); ?>

    </hr>
</div>
<div class="col-sm-4">
    <?php echo $__env->make('centros.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>