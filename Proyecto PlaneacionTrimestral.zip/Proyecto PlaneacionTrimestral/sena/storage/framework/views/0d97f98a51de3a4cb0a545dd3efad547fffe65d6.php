<?php $__env->startSection('content'); ?>
<div class="col-sm-8">
    <h1 class="lead">
        <i class="fa fa-plus">
        </i>
        Adicionar Ambiente
        <a class="btn btn btn-info pull-right" href="<?php echo e(route('ambientes.index')); ?>">
            <i aria-hidden="true" class="fa fa-undo">
                Regresar
            </i>
        </a>
    </h1>
    <hr>
        <?php echo $__env->make('ambientes.fragment.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<?php echo Form::open(['route' => 'ambientes.store']); ?>

			
			<?php echo $__env->make('ambientes.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
		<?php echo Form::close(); ?>

    </hr>
</div>
<div class="col-sm-4">
    <?php echo $__env->make('ambientes.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>