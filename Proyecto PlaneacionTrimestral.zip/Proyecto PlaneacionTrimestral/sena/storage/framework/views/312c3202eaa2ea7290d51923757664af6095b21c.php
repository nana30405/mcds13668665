<?php if(Session::has('info')): ?>
<div class="alert alert-info">
    <button class="close" data-dismiss="alert" type="button">
        ×
    </button>
    <?php echo e(Session::get('info')); ?>

</div>
<?php endif; ?>
