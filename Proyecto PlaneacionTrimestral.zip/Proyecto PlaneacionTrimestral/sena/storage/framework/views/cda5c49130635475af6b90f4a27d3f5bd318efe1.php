<div class="form-group">
    <?php echo Form::label('nomnbre','Nombre del Ambiente'); ?>

	<?php echo Form::text('nombre',null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('estado','Estado  del Ambiente'); ?>

	<?php echo Form::textarea('estado',null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('descripcion','Descripcion del Ambiente'); ?>

	<?php echo Form::textarea('descripcion',null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Guardar',['class'=>'btn btn-success btn-block']); ?>

</div>