<?php $__env->startSection('content'); ?>
<div class="col-sm-8">
    <h1>
        <?php echo e($ambiente->nombre); ?>

        <a class="btn btn-info btn-lg pull-right" href="<?php echo e(route('ambientes.edit',$ambiente->id)); ?>">
            <i class="fa fa-pencil-square-o">
            </i>
        </a>
    </h1>
    <h2>
        <?php echo e($ambiente->descripcion); ?>

    </h2>
    <p>
        <?php echo e($ambiente->short); ?>

    </p>
    <?php echo $ambiente->body; ?>

</div>
<div class="col-sm-4">
    <?php echo $__env->make('ambientes.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>