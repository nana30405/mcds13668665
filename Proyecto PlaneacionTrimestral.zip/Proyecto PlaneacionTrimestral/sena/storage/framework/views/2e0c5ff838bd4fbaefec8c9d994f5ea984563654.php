<div class="form-group">
    <?php echo Form::label('nomnbre','Nombre del Centro'); ?>

	<?php echo Form::text('nombre',null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('descripcion','Descripcion del Centro'); ?>

	<?php echo Form::textarea('descripcion',null,['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Guardar',['class'=>'btn btn-success btn-block']); ?>

</div>