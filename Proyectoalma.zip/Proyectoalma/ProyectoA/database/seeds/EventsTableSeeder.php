<?php

use Illuminate\Database\Seeder;
use App\Event;

class EventsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	  factory(App\Event::class)
        	->times(100)
        	->create();
        //se crean 50 usuarios con factory
     factory(Event::class,100)->create();

    }
}
