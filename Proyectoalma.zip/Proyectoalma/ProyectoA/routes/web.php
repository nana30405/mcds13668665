<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Usuarios
Route::resource('gestion_usuarios', 'UsuarioController');
Route::get('editarAjax/{id}', 'UsuarioController@editarAjax');

// Programas
Route::resource('gestion_programas', 'ProgramaController');
Route::get('editarAjax/{id}', 'ProgramaController@editarAjax');

// Horarios
Route::resource('gestion_horario', 'HorarioController');
Route::get('editarAjax/{id}', 'HorarioController@editarAjax');

// Ambiente
Route::resource('gestion_ambiente', 'AmbienteController');
Route::get('editarAjax/{id}', 'AmbienteController@editarAjax');

// Instructor
Route::resource('gestion_instructor', 'InstructorController');
Route::get('editarAjax/{id}', 'InstructorController@editarAjax');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('codigo', function() {
	return view('codigo');
});

Route::post('codigo', 'UsuarioController@cargar');

// Eventos

Route::get('/', function () {
    return view('home');
});
Route::resource('events', 'EventsController');