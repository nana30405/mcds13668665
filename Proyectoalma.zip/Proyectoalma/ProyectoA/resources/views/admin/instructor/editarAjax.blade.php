@foreach($editar as $edit)
 <form action="{{url('gestion_instructor/'.$edit->id)}}" method="post" enctype="multipart/form-data">
 <input type="hidden" name="_token" value="{{ csrf_token()}}">
    <input type="hidden" name="_method" value="PUT">
<div class="form-group">
    <input type="text" class="form-control" name="programa" placeholder="programa_id" value="{{ $edit->programa_id }}">
  </div>
  <div class="form-group">
    <input type="time" class="form-control" name="horario" placeholder="horario_id" value="{{ $edit->horario_id }}">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="ambiente_formacion" placeholder="ambiente_id" value="{{$edit->ambiente_id}}">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="user" placeholder="user_id" value="{{$edit->user_id}}">
  </div>
  <div class="form-group">
    <input type="hidden" class="form-control" name="id" value="{{ $edit->id }}">
</div>
<div class="modal-footer">
            <button class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <input type="submit" class="btn btn-primary" value="Actualizar Datos">
          </div>
</form>
@endforeach