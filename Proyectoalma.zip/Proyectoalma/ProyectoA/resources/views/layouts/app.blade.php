<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Almacen</title>

    <script src="js/jquery-3.2.1.min.js"></script>

    <!-- Styles -->
    <link href="{{ asset('css/main.css') }}" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">

{!! Html::style('vendor/seguce92/bootstrap/css/bootstrap.min.css') !!}
{!! Html::style('vendor/seguce92/fullcalendar/fullcalendar.min.css') !!}
{!! Html::style('vendor/seguce92/bootstrap-datetimepicker/css/bootstrap-material-datetimepicker.css') !!}
{!! Html::style('vendor/seguce92/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css') !!}

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a class="navbar-brand" href="{{ url('/') }}">Home</a>
                    @if(Auth::check() && Auth::user()->rol == "Administrador")
                    <a class="navbar-brand opt-nav" href="{{ url('gestion_usuarios') }}"> Gestion Usuarios</a>
                    <a class="navbar-brand opt-nav" href="{{ url('gestion_programas') }}"> Gestion Programas</a>
                    <a class="navbar-brand opt-nav" href="{{ url('gestion_horario') }}"> Gestion Horario</a>
                    <a class="navbar-brand opt-nav" href="{{ url('gestion_ambiente') }}"> Gestion Ambiente Formacion</a>
                    <a class="navbar-brand opt-nav" href="{{ url('gestion_instructor') }}"> Gestion Instructor</a>
                    @endif
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ route('login') }}">Ingresar</a></li>
                            <li><a href="{{ route('register') }}">Registrarse</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name}} {{ Auth::user()->apellido}} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Cerrar Sesion
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </nav>

        @yield('content')
    </div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    <script>
    $(document).ready(function(){

      $('.edit').click(function(){

        $id = $(this).attr('data-id');
        var options={url:'http://localhost:8000/editarAjax/'+$id, headers:{'Access-Control-Allow-Origin':'*'}};
        $.get(options,
            

          function(data){
            // console.log(data);
            $('#editar').html(data);
          });
      });
      // $('datetimepicker1').click(function(){
      //    $('#datetimepicker1').datepicker();
      //   });
    });
  </script>
</body>
<!-- calendario de los eventos -->
    
 @if (Auth::guest())

@else
    




<body>
    <div class="container">

        {{ Form::open(['route' => 'events.store', 'method' => 'resource', 'role' => 'form']) }} 
        <!-- se crea una clase modal para que se haga de forma dinamica-->
        <div id="responsive-modal" class="modal fade" tabindex="-1" data-backdrop="static"> 
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Prestamo ambiente</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            {{ Form::label('title', 'AMBIENTE') }}
                            {{ Form::text('title', old('title'), ['class' => 'form-control']) }}
                        </div>
                        <div class="form-group">
                                {{ Form::label('date_start', 'FECHA INICIO') }}
                                {{ Form::text('date_start', old('date_start'), ['class' => 'form-control', 'readonly' => 'true']) }}
                        </div>
                        <div class="form-group">
                            {{ Form::label('time_start', 'HORA INICIO') }}
                            {{ Form::text('time_start', old('time_start'), ['class' => 'form-control']) }}
                        </div>
                        <div class="form-group">
                            {{ Form::label('date_end','FECHA HORA FIN') }}
                            {{ Form::text('date_end', old('date_end'), ['class' => 'form-control']) }}
                        </div>                        
                        <div class="form-group">
                            {{ Form::label('color', 'DISPONIBILIDAD') }}
                            <div class="imput-group colorpicker">
                                {{ Form::text('color', old('color'), ['class' => 'form-control']) }}
                                     <span class="input-group-addon">
                                    <i></i>
                                </span>
                            </div>
                        </div>             
                    </div>                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dafault" data-dismiss="modal">CANCELAR</button>
                         {!! Form::submit('GUARDAR', ['class' => 'btn btn-success']) !!}
                    </div>
                </div>
            </div>
        </div>
        {{ Form::close() }}
        <div id='calendar'></div>
    </div>
      {!!Form::open(['route'=>['events.update', 1],  'method'=>'PUT', 'id'=>'updatemodel'])!!}
    <div id="modal-event" class="modal fade" tabindex="-1" data-backdrop="static">
      <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4>DETALLES DEL AMBIENTE</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                {{ Form::label('title', 'AMBIENTE') }}
                                {{ Form::text('title', old('title'), ['class' => 'form-control']) }}
                            </div>

                            <div class="form-group">
                                {{ Form::label('date_start', 'FECHA INICIO') }}
                                {{ Form::text('date_start', old('date_start'), ['class' => 'form-control']) }}
                            </div>

                            <div class="form-group">
                                {{ Form::label('time_start', 'HORA INICIO') }}
                                {{ Form::text('time_start', old('time_start'), ['class' => 'form-control']) }}
                            </div>

                            <div class="form-group">
                                {{ Form::label('date_end', 'FECHA HORA FIN') }}
                                {{ Form::text('date_end', old('date_end'), ['class' => 'form-control']) }}
                            </div>

                             <div class="form-group">
                                {{ Form::label('_color', 'DISPONIBILIDAD') }}
                                <div class="input-group colorpicker">
                                    {{ Form::text('_color', old('color'), ['class' => 'form-control']) }}
                                    <span class="input-group-addon">
                                        <i></i>
                                    </span>
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <meta name="csrf-token" content="{{ csrf_token() }}">
                            <a id="delete" data-href="{{ url('events') }}" data-id="" class="btn btn-danger">ELIMINAR</a>
                            <button type="button" class="btn btn-dafault" data-dismiss="modal">CANCELAR</button>
                           
                             {!! Form::submit('Modificar', ['class' => 'btn btn-success']) !!}
                        </div>
                    </div>
                </div>
            </div>

        </div>
    
</body>



    {!! Html::script('vendor/seguce92/jquery.min.js') !!}
    {!! Html::script('vendor/seguce92/bootstrap/js/bootstrap.min.js') !!}
    {!! Html::script('vendor/seguce92/fullcalendar/lib/moment.min.js') !!}
    {!! Html::script('vendor/seguce92/fullcalendar/fullcalendar.min.js') !!}
    {!! Html::script('vendor/seguce92/bootstrap-datetimepicker/js/bootstrap-material-datetimepicker.js') !!}
    {!! Html::script('vendor/seguce92/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js') !!}

<script>                                                                                                                                                                                                                                                                                                
var BASEURL ="{{url('/')}}";
$(document).ready(function() {
        
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay,listWeek'
        },
        buttonText: {
        today: 'hoy',
        month: 'mes',
        week: 'semana',
        day: 'dia',
        list: 'Lista',
      },

        navLinks: true, // can click day/week names to navigate views
        editable: true,
        selectable: true,
        selectHelper:true,

        select:function(start){
            start= moment(start.format());
            $('#date_start').val(start.format('YY-MM-DD'));
            $('#responsive-modal').modal('show');
            },

            events: BASEURL + '/events',
                eventClick: function(event, jsEvent, view){
                    var date_start = $.fullCalendar.moment(event.start).format('YYYY-MM-DD');
                    var time_start = $.fullCalendar.moment(event.start).format('hh:mm:ss');
                    var date_end = $.fullCalendar.moment(event.end).format('YYYY-MM-DD');
                    $('#modal-event #delete').attr('data-id', event.id);
                    $('#modal-event #title').val(event.title);
                    $('#modal-event #date_start').val(date_start);
                    $('#modal-event #time_start').val(time_start);
                    $('#modal-event #date_end').val(date_end);
                    $('#modal-event #_color').val(event.color);
                    $('#modal-event').modal('show');
                }
            });
        });
        $('.colorpicker').colorpicker();

        $('#time_start').bootstrapMaterialDatePicker({
            date: false,
            shortTime: false,
            format: 'HH:mm:ss'
        });
        $('#date_end').bootstrapMaterialDatePicker({
            date: true,
            shortTime: false,
            format: 'YYYY-MM-DD HH:mm:ss'
        });

        $('#delete').on('click', function(){
            var x = $(this);
            var delete_url = x.attr('data-href')+'/'+x.attr('data-id');
            $.ajaxSetup({
              headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
            });
            $.ajax({
                url: delete_url,
                type: 'DELETE',
                success: function(result){
                    $('#modal-event').modal('hide');
                    alert(result.message);
                },
                error: function(result){
                    $('#modal-event').modal('hide');
                    alert(result.message);
                }
            });
        });

</script>
@endif
 <!--  Fin calendario de prestamo de ambientes -->
</html>
