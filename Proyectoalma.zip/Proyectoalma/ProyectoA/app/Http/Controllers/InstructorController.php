<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Instructor;
use App\Http\Requests\InstructorRequest;

class InstructorController extends Controller
{
    public function index(){

    $query = Instructor::all();
    return view('admin.instructor.index')->with('query', $query);
  }
  public function store(InstructorRequest $request)
  {
    $inst = new Instructor();
	$inst->programa_id = $request->get('programa_id');
    $inst->horario_id = $request->get('horario_id');
    $inst->ambiente_id = $request->get('ambiente_id');
    $inst->user_id = $request->get('user_id');
    $inst->save();
    return redirect('gestion_instructor')->with('message','Instructor Registrado Con Exito!');
  }
  public function destroy($id)
  {
    Instructor::destroy($id);
      return redirect('gestion_instructor')->with('message','Instructor Eliminada Con Exito!');
  }
  public function show($id)
  {
      return view('gestion_instructor')->with('query', Instructor::find($id));
  }
  public function edit($id)
  {
      
  }
  public function editarAjax($id){

    $editar = Instructor::where('id', '=', $id)->get();
    return view('admin.instructor.editarAjax', compact('editar'));

  }
  public function update(InstructorRequest $request, $id)
  {
    $inst = Instructor::find($id);
   $inst->programa_id = $request->get('programa_id');
    $inst->horario_id = $request->get('horario_id');
    $inst->ambiente_id = $request->get('ambiente_id');
    $inst->user_id = $request->get('user_id');
    $inst->save();
      return redirect('gestion_instructor')->with('message','Instructor Modificada Con Exito!');
  }
}
