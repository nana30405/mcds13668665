<?php $__currentLoopData = $editar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <form action="<?php echo e(url('gestion_instructor/'.$edit->id)); ?>" method="post" enctype="multipart/form-data">
 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <input type="hidden" name="_method" value="PUT">
<div class="form-group">
    <input type="text" class="form-control" name="programa_id" placeholder="programa_id" value="<?php echo e($edit->programa_id); ?>">
  </div>
  <div class="form-group">
    <input type="time" class="form-control" name="horario_id" placeholder="horario_id" value="<?php echo e($edit->horario_id); ?>">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="ambiente_formacion_id" placeholder="ambiente_formacion_id" value="<?php echo e($edit->ambiente_formacion_id); ?>">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="user_id" placeholder="user_id" value="<?php echo e($edit->user_id); ?>">
  </div>
  <div class="form-group">
    <input type="hidden" class="form-control" name="id" value="<?php echo e($edit->id); ?>">
</div>
<div class="modal-footer">
            <button class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <input type="submit" class="btn btn-primary" value="Actualizar Datos">
          </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>