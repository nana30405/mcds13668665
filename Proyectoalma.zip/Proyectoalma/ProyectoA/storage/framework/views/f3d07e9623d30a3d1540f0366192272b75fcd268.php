<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form method="post" action="<?php echo e(url('codigo')); ?>">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<input type="number" name="documento" autofocus="true">		
	</form>

</body>
</html>