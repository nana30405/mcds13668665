<?php $__env->startSection('content'); ?>
  <div class="row">
    <!-- Box Left -->
    <div class="col-lg-1"></div>

    <!-- Box Center -->
    <div class="col-lg-10">

      <!-- Box Titulo -->
      <div class="title">
        <h2 class="text-center">Instructor</h2>
        <hr>
        <br>
      </div>

      <!-- Alert Registro -->
      <?php if(Session::has('message')): ?>
      <div class="alert alert-info alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
          <?php echo e(Session::get('message')); ?>

      </div>
      <?php endif; ?>

      <!-- Box Crear -->
      <div class="col">
        <button class="btn btn-primary" data-toggle="modal" data-target="#modal-crear">Crear Instructor</button>
        <br><br><br>
      </div>
      <!-- Box Table -->
      <div class="col">
        <?php if(!$query->isEmpty()): ?>
        <table class="table table-striped">
          <thead>
            <tr>
              <th class="text-center">Id</th>
              <th class="text-center">Programa</th>
              <th class="text-center">Horarios</th>
              <th class="text-center">Ambiente</th>
              <th class="text-center">Instructor</th>
              <th class="text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="text-center"><?php echo e($row->id); ?></td>
              <td class="text-center"><?php echo e($row->programa->nombre); ?></td>
              <td class="text-center"><?php echo e($row->horario->hora_inicial); ?></td>
              <td class="text-center"><?php echo e($row->ambiente_formacion->nombre); ?></td>
              <td class="text-center"><?php echo e($row->user_id->nombre); ?></td>
              <td class="text-center">
                <button class="btn btn-primary edit" data-id="<?php echo e($row->id); ?>" data-toggle="modal"  data-target="#modal-actualizar">
                  <i class="fa fa-pencil" aria-hidden="true"></i>
                </button>
                <form action="<?php echo e(url('gestion_instructor/'.$row->id)); ?>" method="post" style="display: inline-block;">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="_method" value="delete">
                    <button class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php else: ?>
            <h5 class="text-center">Sin Registros De Instructor...</h5>
        <?php endif; ?>
      </div>

    </div>
    <!-- Box Rigth -->
    <div class="col-lg-1"></div>

    <!-- Modal Registro-->
    <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div id="modal-crear" class="modal fade" role="dialog">
        <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Registrar Instructor</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <input type="text" class="form-control" name="programa_id" placeholder="Programa">
              </div>
              <div class="form-group">
                <input type="date" class="form-control" name="horario_id" placeholder="Horario">
              </div>
              <div class="form-group">
                  <input type="text" class="form-control" name="ambiente_formacion_id" placeholder="Ambiente Formacion">
              </div>
               <div class="form-group">
                  <input type="text" class="form-control" name="user_id" placeholder="Usuario">
              </div>
            </div>
          <div class="modal-footer">
            <button class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <input type="submit" class="btn btn-primary" value="Registrar">
          </div>
        </div>
      </div>
    </div>
  </form>

  <!-- Modal Editar -->
    <div id="modal-actualizar" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Actualizar Datos Instructor</h4>
          </div>
          <div class="modal-body" id="editar">   
          </div>
        </div>
      </div>
    </div>

  </div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>