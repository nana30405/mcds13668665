    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <input type="hidden" name="_method" value="PUT">
      <div id="modal-actualizar" class="modal fade" role="dialog">
        <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Actualizar Datos Usuario</h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                <input type="text" class="form-control" name="name" placeholder="Digite Nombre" value="<?php echo e($editar->name); ?>">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="apellido" placeholder="Digite Apellido" value="<?php echo e($editar->apellido); ?>">
              </div>
              <div class="form-group">
                <input type="number" class="form-control" name="telefono" placeholder="Digite Telefono" value="<?php echo e($editar->telefono); ?>">
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Digite Email" value="<?php echo e($editar->email); ?>">
              </div>
              <div class="form-group">
                <select name="rol" id="roles" class="form-control">
                  <option value="">-- Seleccione Rol --</option>
                  <option value="Administrador">Administrador</option>
                  <option value="Almacen">Almacen</option>
                </select>
              </div>
              <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Digite Password">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="id" value="<?php echo e($editar->id); ?>">
              </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <input type="submit" class="btn btn-primary" value="Actualizar Datos">
          </div>
        </div>
      </div>
    </div>
  </form>