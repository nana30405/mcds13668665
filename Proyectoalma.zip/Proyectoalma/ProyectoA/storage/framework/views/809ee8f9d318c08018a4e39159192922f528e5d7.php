<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Almacen</title>

    <script src="js/jquery-3.2.1.min.js"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">

<?php echo Html::style('vendor/seguce92/bootstrap/css/bootstrap.min.css'); ?>

<?php echo Html::style('vendor/seguce92/fullcalendar/fullcalendar.min.css'); ?>

<?php echo Html::style('vendor/seguce92/bootstrap-datetimepicker/css/bootstrap-material-datetimepicker.css'); ?>

<?php echo Html::style('vendor/seguce92/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css'); ?>


</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Home</a>
                    <?php if(Auth::check() && Auth::user()->rol == "Administrador"): ?>
                    <a class="navbar-brand opt-nav" href="<?php echo e(url('gestion_usuarios')); ?>"> Gestion Usuarios</a>
                    <a class="navbar-brand opt-nav" href="<?php echo e(url('gestion_programas')); ?>"> Gestion Programas</a>
                    <a class="navbar-brand opt-nav" href="<?php echo e(url('gestion_horario')); ?>"> Gestion Horario</a>
                    <a class="navbar-brand opt-nav" href="<?php echo e(url('gestion_ambiente')); ?>"> Gestion Ambiente Formacion</a>
                    <a class="navbar-brand opt-nav" href="<?php echo e(url('gestion_instructor')); ?>"> Gestion Instructor</a>
                    <?php endif; ?>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Ingresar</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Registrarse</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->apellido); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Cerrar Sesion
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
    $(document).ready(function(){

      $('.edit').click(function(){

        $id = $(this).attr('data-id');
        var options={url:'http://localhost:8000/editarAjax/'+$id, headers:{'Access-Control-Allow-Origin':'*'}};
        $.get(options,
            

          function(data){
            // console.log(data);
            $('#editar').html(data);
          });
      });
      // $('datetimepicker1').click(function(){
      //    $('#datetimepicker1').datepicker();
      //   });
    });
  </script>
</body>
<!-- calendario de los eventos -->
    
 <?php if(Auth::guest()): ?>

<?php else: ?>
    




<body>
    <div class="container">

        <?php echo e(Form::open(['route' => 'events.store', 'method' => 'resource', 'role' => 'form'])); ?> 
        <!-- se crea una clase modal para que se haga de forma dinamica-->
        <div id="responsive-modal" class="modal fade" tabindex="-1" data-backdrop="static"> 
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Prestamo ambiente</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php echo e(Form::label('title', 'AMBIENTE')); ?>

                            <?php echo e(Form::text('title', old('title'), ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                                <?php echo e(Form::label('date_start', 'FECHA INICIO')); ?>

                                <?php echo e(Form::text('date_start', old('date_start'), ['class' => 'form-control', 'readonly' => 'true'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('time_start', 'HORA INICIO')); ?>

                            <?php echo e(Form::text('time_start', old('time_start'), ['class' => 'form-control'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('date_end','FECHA HORA FIN')); ?>

                            <?php echo e(Form::text('date_end', old('date_end'), ['class' => 'form-control'])); ?>

                        </div>                        
                        <div class="form-group">
                            <?php echo e(Form::label('color', 'DISPONIBILIDAD')); ?>

                            <div class="imput-group colorpicker">
                                <?php echo e(Form::text('color', old('color'), ['class' => 'form-control'])); ?>

                                     <span class="input-group-addon">
                                    <i></i>
                                </span>
                            </div>
                        </div>             
                    </div>                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dafault" data-dismiss="modal">CANCELAR</button>
                         <?php echo Form::submit('GUARDAR', ['class' => 'btn btn-success']); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php echo e(Form::close()); ?>

        <div id='calendar'></div>
    </div>
      <?php echo Form::open(['route'=>['events.update', 1],  'method'=>'PUT', 'id'=>'updatemodel']); ?>

    <div id="modal-event" class="modal fade" tabindex="-1" data-backdrop="static">
      <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4>DETALLES DEL AMBIENTE</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <?php echo e(Form::label('title', 'AMBIENTE')); ?>

                                <?php echo e(Form::text('title', old('title'), ['class' => 'form-control'])); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('date_start', 'FECHA INICIO')); ?>

                                <?php echo e(Form::text('date_start', old('date_start'), ['class' => 'form-control'])); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('time_start', 'HORA INICIO')); ?>

                                <?php echo e(Form::text('time_start', old('time_start'), ['class' => 'form-control'])); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('date_end', 'FECHA HORA FIN')); ?>

                                <?php echo e(Form::text('date_end', old('date_end'), ['class' => 'form-control'])); ?>

                            </div>

                             <div class="form-group">
                                <?php echo e(Form::label('_color', 'DISPONIBILIDAD')); ?>

                                <div class="input-group colorpicker">
                                    <?php echo e(Form::text('_color', old('color'), ['class' => 'form-control'])); ?>

                                    <span class="input-group-addon">
                                        <i></i>
                                    </span>
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
                            <a id="delete" data-href="<?php echo e(url('events')); ?>" data-id="" class="btn btn-danger">ELIMINAR</a>
                            <button type="button" class="btn btn-dafault" data-dismiss="modal">CANCELAR</button>
                           
                             <?php echo Form::submit('Modificar', ['class' => 'btn btn-success']); ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    
</body>



    <?php echo Html::script('vendor/seguce92/jquery.min.js'); ?>

    <?php echo Html::script('vendor/seguce92/bootstrap/js/bootstrap.min.js'); ?>

    <?php echo Html::script('vendor/seguce92/fullcalendar/lib/moment.min.js'); ?>

    <?php echo Html::script('vendor/seguce92/fullcalendar/fullcalendar.min.js'); ?>

    <?php echo Html::script('vendor/seguce92/bootstrap-datetimepicker/js/bootstrap-material-datetimepicker.js'); ?>

    <?php echo Html::script('vendor/seguce92/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js'); ?>


<script>                                                                                                                                                                                                                                                                                                
var BASEURL ="<?php echo e(url('/')); ?>";
$(document).ready(function() {
        
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay,listWeek'
        },
        buttonText: {
        today: 'hoy',
        month: 'mes',
        week: 'semana',
        day: 'dia',
        list: 'Lista',
      },

        navLinks: true, // can click day/week names to navigate views
        editable: true,
        selectable: true,
        selectHelper:true,

        select:function(start){
            start= moment(start.format());
            $('#date_start').val(start.format('YY-MM-DD'));
            $('#responsive-modal').modal('show');
            },

            events: BASEURL + '/events',
                eventClick: function(event, jsEvent, view){
                    var date_start = $.fullCalendar.moment(event.start).format('YYYY-MM-DD');
                    var time_start = $.fullCalendar.moment(event.start).format('hh:mm:ss');
                    var date_end = $.fullCalendar.moment(event.end).format('YYYY-MM-DD');
                    $('#modal-event #delete').attr('data-id', event.id);
                    $('#modal-event #title').val(event.title);
                    $('#modal-event #date_start').val(date_start);
                    $('#modal-event #time_start').val(time_start);
                    $('#modal-event #date_end').val(date_end);
                    $('#modal-event #_color').val(event.color);
                    $('#modal-event').modal('show');
                }
            });
        });
        $('.colorpicker').colorpicker();

        $('#time_start').bootstrapMaterialDatePicker({
            date: false,
            shortTime: false,
            format: 'HH:mm:ss'
        });
        $('#date_end').bootstrapMaterialDatePicker({
            date: true,
            shortTime: false,
            format: 'YYYY-MM-DD HH:mm:ss'
        });

        $('#delete').on('click', function(){
            var x = $(this);
            var delete_url = x.attr('data-href')+'/'+x.attr('data-id');
            $.ajaxSetup({
              headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
            });
            $.ajax({
                url: delete_url,
                type: 'DELETE',
                success: function(result){
                    $('#modal-event').modal('hide');
                    alert(result.message);
                },
                error: function(result){
                    $('#modal-event').modal('hide');
                    alert(result.message);
                }
            });
        });

</script>
<?php endif; ?>
 <!--  Fin calendario de prestamo de ambientes -->
</html>
