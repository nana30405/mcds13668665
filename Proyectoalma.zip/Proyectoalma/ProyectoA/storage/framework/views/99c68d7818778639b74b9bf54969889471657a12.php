<?php $__currentLoopData = $editar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <form action="<?php echo e(url('gestion_programas/'.$edit->id)); ?>" method="post" enctype="multipart/form-data">
 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <input type="hidden" name="_method" value="PUT">
<div class="form-group">
    <input type="text" class="form-control" name="nombre" placeholder="Digite Nombre" value="<?php echo e($edit->nombre); ?>">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="codigo" placeholder="Digite Codigo" value="<?php echo e($edit->codigo); ?>">
  </div>
  <div class="form-group">
    <input type="date" class="form-control" name="fecha_vencimiento" placeholder="Digite Fecha Vencimiento" value="<?php echo e($edit->fecha_vencimiento); ?>">
  </div>
  <div class="form-group">
    <input type="hidden" class="form-control" name="id" value="<?php echo e($edit->id); ?>">
</div>
<div class="modal-footer">
            <button class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <input type="submit" class="btn btn-primary" value="Actualizar Datos">
          </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>